﻿namespace Contoso.Apps.SportsLeague.Web.Models
{
    public class CategoryModel
    {
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }
    }
}